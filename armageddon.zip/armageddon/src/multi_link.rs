use anyhow::Result;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use crate::transport::Transport;

/// Simple round‑robin multi‑link: send each packet to next transport.
pub struct MultiLink {
    transports: Vec<Arc<dyn Transport>>,
    counter: std::sync::atomic::AtomicUsize,
}

impl MultiLink {
    pub fn new(transports: Vec<Arc<dyn Transport>>) -> Self {
        Self {
            transports,
            counter: std::sync::atomic::AtomicUsize::new(0),
        }
    }

    pub async fn connect(&self, addr: &str, port: u16) -> Result<Box<dyn super::transport::AsyncReadWrite>> {
        let idx = self.counter.fetch_add(1, std::sync::atomic::Ordering::Relaxed) % self.transports.len();
        self.transports[idx].connect(addr, port).await
    }
}