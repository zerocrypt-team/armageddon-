mod banner;
mod config;
mod error;
mod platform;
mod packet_builder;
mod injector;
mod interceptor;
mod evasion;
mod chaos_engine;
mod rtt;
mod gateway;
mod transport;
mod scout;
mod cli;
mod profiles;
mod learner;
mod advisor;
mod novel;
mod gui;

// Phase 8 modules
mod cartographer;
mod honeypot;
mod multi_link;
mod stealth;
mod marketplace;
mod ech;
mod session_replay;
mod shadow_traffic;
mod ai_mutator;

use anyhow::Result;

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();

    let args = cli::parse_args();
    if args.command.is_none() {
        println!("{}", banner::BANNER);
        gui::run_gui().await?;
        return Ok(());
    }

    println!("{}", banner::BANNER);
    cli::execute(args.command.unwrap(), args.config_path).await
}