use crate::error::ArmageddonError;

#[cfg(target_os = "linux")]
pub fn ensure_root() -> Result<(), ArmageddonError> {
    if !nix::unistd::Uid::effective().is_root() {
        return Err(ArmageddonError::PermissionDenied);
    }
    Ok(())
}

#[cfg(target_os = "windows")]
pub fn ensure_admin() -> Result<(), ArmageddonError> {
    // Simple check: try to open a privileged resource, or use windows-sys.
    // For now we rely on the user to run as Administrator.
    // In future we can call `IsUserAnAdmin()` from shell32.
    Ok(())
}