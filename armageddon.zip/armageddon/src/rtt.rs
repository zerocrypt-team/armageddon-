use anyhow::Result;
use std::net::Ipv4Addr;
use crate::injector::linux::LinuxRawSocket;

pub async fn estimate_rtt(
    _raw: &LinuxRawSocket,
    _dst_ip: Ipv4Addr,
    _dst_port: u16,
    fallback_ms: u64,
) -> Result<u64> {
    Ok(fallback_ms)
}