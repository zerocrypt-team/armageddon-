use anyhow::Result;
use serde::Deserialize;
use std::fs;
use tokio::net::TcpStream;
use std::time::Duration;

#[derive(Debug, Deserialize)]
pub struct RelayList {
    pub relays: Vec<Relay>,
}

#[derive(Debug, Deserialize)]
pub struct Relay {
    pub name: String,
    pub url: String,
    pub transport: String,
}

pub async fn load_relays(path: &str) -> Result<RelayList> {
    let content = fs::read_to_string(path)?;
    Ok(serde_json::from_str(&content)?)
}

pub async fn test_relay(url: &str, timeout_secs: u64) -> bool {
    // Simple TCP connect test
    if let Ok(addr) = url_to_socket_addr(url) {
        match tokio::time::timeout(
            Duration::from_secs(timeout_secs),
            TcpStream::connect(&addr),
        )
        .await
        {
            Ok(Ok(_)) => true,
            _ => false,
        }
    } else {
        false
    }
}

fn url_to_socket_addr(url: &str) -> Result<std::net::SocketAddr> {
    // Simplistic: assume url like "host:port" or "wss://host:port"
    let s = url
        .trim_start_matches("ws://")
        .trim_start_matches("wss://")
        .trim_start_matches("ss://");
    let parts: Vec<&str> = s.split(':').collect();
    if parts.len() != 2 {
        anyhow::bail!("Invalid relay URL format");
    }
    let port: u16 = parts[1].parse()?;
    let addr = format!("{}:{}", parts[0], port);
    Ok(addr.parse()?)
}