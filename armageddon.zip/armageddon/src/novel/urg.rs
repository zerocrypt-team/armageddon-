use anyhow::Result;
use std::net::Ipv4Addr;
use std::sync::Arc;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::{tcp, ip};
use rand::Rng;

pub async fn apply(
    injector: &Arc<LinuxRawSocket>,
    src: Ipv4Addr,
    dst: Ipv4Addr,
    sport: u16,
    dport: u16,
    seq: u32,
    ack: u32,
) -> Result<()> {
    let mut rng = rand::thread_rng();
    let tcp_pkt = tcp::build_tcp_packet(
        src, dst,
        &tcp::TcpOptions {
            seq, ack, sport, dport,
            window: rng.gen_range(1024..65535),
            flags: 0x20, // URG
            urg: true,
            urg_ptr: rng.gen(),
            timestamp: None,
        },
        &[], // no payload
    )?;
    ip::send_tcp_via_ip(injector, src, dst, &tcp_pkt, 1, rng.gen(), 0, false).await?;
    Ok(())
}