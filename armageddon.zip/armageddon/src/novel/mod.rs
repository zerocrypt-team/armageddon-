use anyhow::Result;
use std::net::Ipv4Addr;
use std::sync::Arc;
use crate::config::NovelConfig;
use crate::injector::linux::LinuxRawSocket;

pub mod urg;
pub mod sack;
pub mod alpn;

/// Execute all enabled novel methods for the current packet context.
pub async fn execute_all(
    config: &NovelConfig,
    injector: &Arc<LinuxRawSocket>,
    src_ip: Ipv4Addr,
    dst_ip: Ipv4Addr,
    src_port: u16,
    dst_port: u16,
    real_seq: u32,
    real_ack: u32,
    payload: &[u8],
) -> Result<()> {
    if config.urg_diversion {
        urg::apply(injector, src_ip, dst_ip, src_port, dst_port, real_seq, real_ack).await?;
    }
    if config.sack_spoofing {
        sack::apply(injector, src_ip, dst_ip, src_port, dst_port, real_seq, real_ack).await?;
    }
    if config.alpn_randomization {
        alpn::apply(injector, src_ip, dst_ip, src_port, dst_port, real_seq, real_ack, payload).await?;
    }
    // Other methods can be added later
    Ok(())
}