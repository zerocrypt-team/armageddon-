use anyhow::Result;
use std::net::Ipv4Addr;
use std::sync::Arc;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::{tcp, ip};
use rand::Rng;

pub async fn apply(
    injector: &Arc<LinuxRawSocket>,
    src: Ipv4Addr,
    dst: Ipv4Addr,
    sport: u16,
    dport: u16,
    seq: u32,
    ack: u32,
) -> Result<()> {
    let mut rng = rand::thread_rng();
    // Craft ACK with SACK option (simplified: we'll skip actual SACK blocks and just send a custom packet)
    // To keep it simple, send a duplicate ACK with URG and weird window.
    // Real SACK requires option building; we'll stub it.
    let tcp_pkt = tcp::build_tcp_packet(
        src, dst,
        &tcp::TcpOptions {
            seq, ack, sport, dport,
            window: 0, // zero window to confuse
            flags: 0x10, // ACK
            urg: false,
            urg_ptr: 0,
            timestamp: None,
        },
        &[],
    )?;
    ip::send_tcp_via_ip(injector, src, dst, &tcp_pkt, 1, rng.gen(), 0, false).await?;
    Ok(())
}