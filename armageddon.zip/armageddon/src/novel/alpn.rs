use anyhow::Result;
use std::net::Ipv4Addr;
use std::sync::Arc;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::{tcp, ip, tls};
use rand::Rng;

pub async fn apply(
    injector: &Arc<LinuxRawSocket>,
    src: Ipv4Addr,
    dst: Ipv4Addr,
    sport: u16,
    dport: u16,
    seq: u32,
    ack: u32,
    original_payload: &[u8],
) -> Result<()> {
    // Modify the ClientHello to include random ALPN protocols
    let mut rng = rand::thread_rng();
    let fake_sni = "cloudflare.com"; // could be random
    let fake_hello = tls::build_fake_client_hello(fake_sni, &mut rng)?;
    // Append custom ALPN extension (simplistic)
    let mut mod_hello = fake_hello.clone();
    let alpn_ext = b"\x00\x10\x00\x06\x05h2\x08http/1.1"; // example ALPN
    mod_hello.extend_from_slice(alpn_ext);
    // Send as a Ghost-like packet
    let tcp_pkt = tcp::build_tcp_packet(
        src, dst,
        &tcp::TcpOptions {
            seq: seq.wrapping_add(1000),
            ack,
            sport,
            dport,
            window: 65535,
            flags: 0x10,
            urg: false,
            urg_ptr: 0,
            timestamp: None,
        },
        &mod_hello,
    )?;
    ip::send_tcp_via_ip(injector, src, dst, &tcp_pkt, 1, rng.gen(), 0, false).await?;
    Ok(())
}