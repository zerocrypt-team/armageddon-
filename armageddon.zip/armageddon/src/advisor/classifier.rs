use super::DpiType;

pub fn classify(raw: &DpiType) -> DpiType {
    // Currently just pass through; future implementation may aggregate multiple probe results
    raw.clone()
}