use super::{DpiType, Strategy};
use crate::config::Config;

pub fn recommend(dpi: &DpiType, _config: &Config) -> Vec<Strategy> {
    match dpi {
        DpiType::None => vec![Strategy {
            label: "No evasion needed".into(),
            profile: "none".into(),
            description: "DPI is not active, direct connection works.".into(),
        }],
        DpiType::SimpleRst => vec![
            Strategy {
                label: "⚡ Fast".into(),
                profile: "fragment-king".into(),
                description: "Simple fragmentation bypasses RST injection.".into(),
            },
        ],
        DpiType::StatefulTcp => vec![
            Strategy {
                label: "⚖ Balanced".into(),
                profile: "stealth-combo".into(),
                description: "Ghost + Fragment + Retro + Noise at moderate level.".into(),
            },
            Strategy {
                label: "🛡 Guaranteed".into(),
                profile: "apocalypse".into(),
                description: "Maximum protection with all methods.".into(),
            },
        ],
        DpiType::DeepTls => vec![
            Strategy {
                label: "⚖ Balanced".into(),
                profile: "stealth-combo".into(),
                description: "Multi-layer evasion with uTLS and GREASE.".into(),
            },
            Strategy {
                label: "🛡 Guaranteed".into(),
                profile: "apocalypse".into(),
                description: "All methods including Novel techniques.".into(),
            },
        ],
        DpiType::Unknown => vec![
            Strategy {
                label: "🛡 Guaranteed".into(),
                profile: "apocalypse".into(),
                description: "Maximum evasion (safe fallback).".into(),
            },
        ],
    }
}