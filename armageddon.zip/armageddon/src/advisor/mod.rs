pub mod probe;
pub mod classifier;
pub mod strategy;

use anyhow::Result;
use crate::config::Config;

/// Run DPI analysis and return a structured result.
pub async fn run_analysis(config: &Config, quick: bool) -> Result<AnalysisResult> {
    let dpi_type = if quick {
        probe::quick_probe().await?
    } else {
        probe::full_probe().await?
    };
    let classification = classifier::classify(&dpi_type);
    Ok(AnalysisResult {
        dpi_type: classification,
        strategies: strategy::recommend(&classification, config),
    })
}

#[derive(Debug)]
pub struct AnalysisResult {
    pub dpi_type: DpiType,
    pub strategies: Vec<Strategy>,
}

#[derive(Debug, Clone)]
pub enum DpiType {
    None,
    SimpleRst,
    StatefulTcp,
    DeepTls,
    Unknown,
}

impl std::fmt::Display for DpiType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DpiType::None => write!(f, "No DPI detected"),
            DpiType::SimpleRst => write!(f, "Simple RST injection"),
            DpiType::StatefulTcp => write!(f, "Stateful TCP"),
            DpiType::DeepTls => write!(f, "Deep TLS inspection"),
            DpiType::Unknown => write!(f, "Unknown DPI pattern"),
        }
    }
}

#[derive(Debug, Clone)]
pub struct Strategy {
    pub label: String,
    pub profile: String,
    pub description: String,
}