use serde::{Serialize, Deserialize};
use std::collections::HashMap;
use std::path::PathBuf;
use std::fs;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DomainProfile {
    pub ghost_count: usize,
    pub fragment_count: usize,
    pub retro_enabled: bool,
    pub success: u64,
    pub fail: u64,
}

impl Default for DomainProfile {
    fn default() -> Self {
        Self {
            ghost_count: 3,
            fragment_count: 3,
            retro_enabled: true,
            success: 0,
            fail: 0,
        }
    }
}

pub struct Learner {
    db: HashMap<String, DomainProfile>,
    path: Option<PathBuf>,
}

impl Learner {
    pub fn new(persist_path: Option<PathBuf>) -> Self {
        let mut db = HashMap::new();
        if let Some(ref p) = persist_path {
            if let Ok(data) = fs::read_to_string(p) {
                if let Ok(parsed) = serde_json::from_str::<HashMap<String, DomainProfile>>(&data) {
                    db = parsed;
                }
            }
        }
        Self { db, path: persist_path }
    }

    pub fn report_success(&mut self, domain: &str) {
        let entry = self.db.entry(domain.to_string()).or_default();
        entry.success += 1;
        self.persist();
    }

    pub fn report_failure(&mut self, domain: &str) {
        let entry = self.db.entry(domain.to_string()).or_default();
        entry.fail += 1;
        if entry.fail > 3 {
            entry.ghost_count = (entry.ghost_count + 1).min(10);
            entry.fragment_count = (entry.fragment_count + 1).min(8);
            entry.retro_enabled = true;
        }
        self.persist();
    }

    pub fn get_profile(&self, domain: &str) -> Option<&DomainProfile> {
        self.db.get(domain)
    }

    fn persist(&self) {
        if let Some(ref p) = self.path {
            let _ = serde_json::to_string_pretty(&self.db).map(|data| fs::write(p, data));
        }
    }
}