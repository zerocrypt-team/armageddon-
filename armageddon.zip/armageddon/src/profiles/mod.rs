pub mod presets;
pub mod merge;
pub mod validator;

use serde::{Serialize, Deserialize};
use crate::config::Config;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Profile {
    pub name: String,
    pub config: Config,
}

impl Profile {
    pub fn new(name: impl Into<String>, config: Config) -> Self {
        Self {
            name: name.into(),
            config,
        }
    }

    /// Return list of all built‑in presets.
    pub fn builtin() -> Vec<Profile> {
        presets::all()
    }
}