use super::Profile;

pub fn validate(profile: &Profile) -> Vec<String> {
    let mut warnings = vec![];

    if profile.config.retro.enabled && !profile.config.ghost.enabled {
        warnings.push("Retro enabled without Ghost – may have limited effect.".into());
    }

    if profile.config.noise.enabled
        && !profile.config.ghost.enabled
        && !profile.config.fragment.enabled
    {
        warnings.push("Noise enabled alone – ensure you have a fallback method.".into());
    }

    warnings
}