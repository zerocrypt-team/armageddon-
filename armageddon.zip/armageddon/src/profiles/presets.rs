use super::Profile;
use crate::config::{
    Config, GhostConfig, FragmentConfig, RetroConfig, NoiseConfig, NovelConfig,
};

/// All built‑in profiles.
pub fn all() -> Vec<Profile> {
    vec![
        apocalypse(),
        ghost_rider(),
        fragment_king(),
        retro_wave(),
        noise_storm(),
        stealth_combo(),
        novel_breaker(),
    ]
}

// ----------------------------------------------------------------
// Apocalypse – every method enabled with maximum (default) values
// ----------------------------------------------------------------
pub fn apocalypse() -> Profile {
    Profile::new("apocalypse", Config::default())
}

// ----------------------------------------------------------------
// Ghost Rider – only Ghost Storm, highly aggressive
// ----------------------------------------------------------------
pub fn ghost_rider() -> Profile {
    let mut cfg = Config::default();
    cfg.ghost = GhostConfig {
        enabled: true,
        min_count: 5,
        max_count: 12,
        ttl_min: 1,
        ttl_max: 3,
        seq_offset_min: 2000,
        seq_offset_max: 20000,
        header_hide_prob: 0.4,
        urg_prob: 0.3,
        zero_window_prob: 0.2,
    };
    cfg.fragment.enabled = false;
    cfg.retro.enabled   = false;
    cfg.noise.enabled   = false;
    cfg.novel = NovelConfig::default();  // all off
    Profile::new("ghost-rider", cfg)
}

// ----------------------------------------------------------------
// Fragment King – only IP fragmentation + GREASE
// ----------------------------------------------------------------
pub fn fragment_king() -> Profile {
    let mut cfg = Config::default();
    cfg.ghost.enabled   = false;
    cfg.fragment = FragmentConfig {
        enabled: true,
        min_frags: 5,
        max_frags: 8,
        grease_enabled: true,
        grease_size_min: 50,
        grease_size_max: 200,
        sn_safe: true,
    };
    cfg.retro.enabled = false;
    cfg.noise.enabled = false;
    cfg.novel = NovelConfig::default();
    Profile::new("fragment-king", cfg)
}

// ----------------------------------------------------------------
// Retro Wave – Ghost (moderate) + Retro rewrite
// ----------------------------------------------------------------
pub fn retro_wave() -> Profile {
    let mut cfg = Config::default();
    cfg.ghost = GhostConfig {
        enabled: true,
        min_count: 3,
        max_count: 6,
        ttl_min: 1,
        ttl_max: 3,
        seq_offset_min: 2000,
        seq_offset_max: 20000,
        header_hide_prob: 0.3,
        urg_prob: 0.2,
        zero_window_prob: 0.1,
    };
    cfg.fragment.enabled = false;
    cfg.retro = RetroConfig {
        enabled: true,
        probability: 0.9,
        rtt_threshold_ms: 30,
        use_timestamp: true,
    };
    cfg.noise.enabled = false;
    cfg.novel = NovelConfig::default();
    Profile::new("retro-wave", cfg)
}

// ----------------------------------------------------------------
// Noise Storm – heavy background noise only
// ----------------------------------------------------------------
pub fn noise_storm() -> Profile {
    let mut cfg = Config::default();
    cfg.ghost.enabled   = false;
    cfg.fragment.enabled = false;
    cfg.retro.enabled   = false;
    cfg.noise = NoiseConfig {
        enabled: true,
        min_count: 3,
        max_count: 8,
        delay_shape: 2.0,
        delay_scale: 1000.0,
    };
    cfg.novel = NovelConfig::default();
    Profile::new("noise-storm", cfg)
}

// ----------------------------------------------------------------
// Stealth Combo – all four classic methods enabled at default strength
// ----------------------------------------------------------------
pub fn stealth_combo() -> Profile {
    let mut cfg = Config::default();
    cfg.ghost.enabled    = true;
    cfg.fragment.enabled = true;
    cfg.retro.enabled    = true;
    cfg.noise.enabled    = true;
    cfg.novel = NovelConfig::default(); // novel still off
    Profile::new("stealth-combo", cfg)
}

// ----------------------------------------------------------------
// Novel Breaker – classic methods + proprietary novel techniques
// ----------------------------------------------------------------
pub fn novel_breaker() -> Profile {
    let mut cfg = Config::default();
    cfg.ghost.enabled    = true;
    cfg.fragment.enabled = true;
    cfg.retro.enabled    = true;
    cfg.noise.enabled    = true;
    cfg.novel = NovelConfig {
        urg_diversion:        true,
        sack_spoofing:        true,
        alpn_randomization:   true,
        fin_bomb:             false,   // high‑risk, off by default
        dscp_confusion:       false,   // not yet implemented
        timestamp_side_channel: false, // not yet implemented
        window_pattern:       false,
        ecn_toggle:           false,
    };
    Profile::new("novel-breaker", cfg)
}