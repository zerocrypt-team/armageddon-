use super::Profile;
use crate::config::Config;

/// Merge two profiles by taking non‑default values from `secondary`,
/// falling back to `primary`.
pub fn merge(primary: &Profile, secondary: &Profile) -> Profile {
    let mut cfg = primary.config.clone();

    // Ghost: if secondary enabled, use its values
    if secondary.config.ghost.enabled {
        cfg.ghost = secondary.config.ghost.clone();
    }

    // Fragment
    if secondary.config.fragment.enabled {
        cfg.fragment = secondary.config.fragment.clone();
    }

    // Retro
    if secondary.config.retro.enabled {
        cfg.retro = secondary.config.retro.clone();
    }

    // Noise
    if secondary.config.noise.enabled {
        cfg.noise = secondary.config.noise.clone();
    }

    // uTLS (if later used)
    cfg.utls = secondary.config.utls.clone();

    // Novel (if later used)
    cfg.novel = secondary.config.novel.clone();

    let name = format!("{}+{}", primary.name, secondary.name);
    Profile::new(name, cfg)
}