#[cfg(target_os = "linux")]
pub mod linux;
#[cfg(target_os = "windows")]
pub mod windows;

#[cfg(target_os = "linux")]
pub use linux::LinuxRawSocket;
#[cfg(target_os = "windows")]
pub use windows::WindowsRawSocket;