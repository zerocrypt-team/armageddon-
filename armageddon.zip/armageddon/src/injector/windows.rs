use anyhow::Result;
use std::net::Ipv4Addr;

pub struct WindowsRawSocket;

impl WindowsRawSocket {
    pub fn new() -> Result<Self> {
        log::warn!("WindowsRawSocket not yet implemented");
        Ok(Self)
    }

    pub async fn send_ip_packet(&self, _dst: Ipv4Addr, _packet: &[u8]) -> Result<()> {
        unimplemented!("send_ip_packet not available on Windows yet")
    }
}