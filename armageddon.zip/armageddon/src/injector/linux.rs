use anyhow::Result;
use socket2::{Socket, Domain, Type, Protocol};
use std::net::{Ipv4Addr, SocketAddrV4};
use std::os::unix::io::AsRawFd;

pub struct LinuxRawSocket {
    socket: Socket,
}

impl LinuxRawSocket {
    pub fn new() -> Result<Self> {
        let socket = Socket::new(Domain::IPV4, Type::RAW, Some(Protocol::from(255)))?;
        socket.set_header_included(true)?;
        Ok(Self { socket })
    }

    pub async fn send_ip_packet(&self, dst: Ipv4Addr, packet: &[u8]) -> Result<()> {
        let addr = SocketAddrV4::new(dst, 0);
        let sockaddr = socket2::SockAddr::from(addr);
        let fd = self.socket.as_raw_fd();
        let buf = packet.to_vec();
        let len = buf.len();
        tokio::task::spawn_blocking(move || unsafe {
            let sent = libc::sendto(
                fd,
                buf.as_ptr() as *const libc::c_void,
                len,
                0,
                sockaddr.as_ptr(),
                sockaddr.len(),
            );
            if sent < 0 {
                Err(anyhow::anyhow!("sendto failed: {}", std::io::Error::last_os_error()))
            } else {
                Ok(())
            }
        })
        .await??;
        Ok(())
    }
}