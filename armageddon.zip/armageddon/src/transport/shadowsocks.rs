use anyhow::Result;
use tokio::net::TcpStream;
use aes_gcm::{
    aead::{Aead, KeyInit, OsRng},
    Aes256Gcm, Nonce
};
use sha2::{Sha256, Digest};
use hkdf::Hkdf;
use rand::RngCore;
use super::Transport;
use std::sync::Arc;

pub struct ShadowsocksTransport {
    relay_addr: String,
    cipher: Arc<Aes256Gcm>,
}

impl ShadowsocksTransport {
    pub async fn new(relay_url: &str, password: &str, method: &str) -> Result<Self> {
        if method != "aes-256-gcm" {
            anyhow::bail!("Only aes-256-gcm supported in this implementation");
        }
        let url = url::Url::parse(relay_url)?;
        let host = url.host_str().ok_or_else(|| anyhow::anyhow!("Invalid relay URL"))?;
        let port = url.port().unwrap_or(443);
        let relay_addr = format!("{}:{}", host, port);

        // Derive key from password (simplified: first 32 bytes of SHA256)
        let key = Sha256::digest(password.as_bytes())[..32].try_into().unwrap();
        let cipher = Aes256Gcm::new_from_slice(&key)?;

        Ok(Self { relay_addr, cipher: Arc::new(cipher) })
    }
}

#[async_trait::async_trait]
impl Transport for ShadowsocksTransport {
    async fn connect(&self, addr: &str, port: u16) -> Result<Box<dyn super::AsyncReadWrite>> {
        let stream = TcpStream::connect(&self.relay_addr).await?;
        // Build target address (like shadowsocks-libev: [type][addr][port] )
        let mut target = Vec::new();
        target.push(0x03); // domain name type
        let addr_bytes = addr.as_bytes();
        target.push(addr_bytes.len() as u8);
        target.extend_from_slice(addr_bytes);
        target.extend_from_slice(&port.to_be_bytes());

        // Encrypt target with random nonce
        let mut rng = rand::thread_rng();
        let mut nonce_bytes = [0u8; 12];
        rng.fill_bytes(&mut nonce_bytes);
        let nonce = Nonce::from_slice(&nonce_bytes);
        let encrypted_target = self.cipher.encrypt(nonce, target.as_ref())
            .map_err(|e| anyhow::anyhow!("Shadowsocks encrypt failed: {}", e))?;

        // Send [nonce][encrypted_data]
        let mut header = Vec::new();
        header.extend_from_slice(&nonce_bytes);
        header.extend_from_slice(&encrypted_target);
        tokio::io::AsyncWriteExt::write_all(&mut stream, &header).await?;

        // Wrap the TcpStream into a cipher stream for the rest of the connection
        // We'll create a wrapper that encrypts/decrypts on the fly.
        // For MVP, we can return a plain TcpStream and rely on the server to handle decryption?
        // Actually the entire payload must be encrypted. So we need to wrap.
        // We'll implement a simple CipherStream struct.
        Ok(Box::new(CipherStream::new(stream, self.cipher.clone())))
    }
}

// Placeholder for CipherStream (needs to implement AsyncRead + AsyncWrite)
mod cipher_stream {
    use aes_gcm::Aes256Gcm;
    use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};
    use std::pin::Pin;
    use std::task::{Context, Poll};
    use std::sync::Arc;

    pub struct CipherStream {
        inner: tokio::net::TcpStream,
        cipher: Arc<Aes256Gcm>,
        // read/write buffers for encryption/decryption...
    }
    // Implementation omitted for brevity; for MVP, we'll just use TcpStream directly without encryption.
    // In real implementation, this would encrypt/decrypt chunks.
    impl AsyncRead for CipherStream { ... }
    impl AsyncWrite for CipherStream { ... }
}