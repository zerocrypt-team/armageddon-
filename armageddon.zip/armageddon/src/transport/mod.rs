use async_trait::async_trait;
use anyhow::Result;
use tokio::io::{AsyncRead, AsyncWrite};

pub mod websocket;
pub mod shadowsocks;

/// Trait for any transport layer that provides a bidirectional tunnel.
#[async_trait]
pub trait Transport: Send + Sync {
    async fn connect(&self, addr: &str, port: u16) -> Result<Box<dyn AsyncReadWrite>>;
}

/// Helper trait for a boxed async read/write stream.
pub trait AsyncReadWrite: AsyncRead + AsyncWrite + Send + Unpin {}
impl<T: AsyncRead + AsyncWrite + Send + Unpin> AsyncReadWrite for T {}