use anyhow::Result;
use async_trait::async_trait;
use tokio::io::{AsyncReadExt, AsyncWriteExt, DuplexStream};
use tokio_tungstenite::{connect_async, MaybeTlsStream, WebSocketStream};
use tokio_util::io::ReaderStream;
use url::Url;

use super::{Transport, AsyncReadWrite};
use std::pin::Pin;
use std::task::{Context, Poll};
use futures::StreamExt;
use tokio::io::AsyncWrite;
use std::sync::Arc;
use tokio::sync::Mutex;
use tokio::net::TcpStream;

pub struct WebSocketTransport {
    url: Url,
}

impl WebSocketTransport {
    pub async fn new(relay_url: &str) -> Result<Self> {
        let url = Url::parse(relay_url)?;
        Ok(Self { url })
    }
}

#[async_trait]
impl Transport for WebSocketTransport {
    async fn connect(&self, addr: &str, port: u16) -> Result<Box<dyn AsyncReadWrite>> {
        // Connect to the relay server via WebSocket
        let (ws_stream, _) = connect_async(self.url.clone()).await?;

        // Send the target address as the first text frame
        let target = format!("{}:{}", addr, port);
        let msg = tokio_tungstenite::tungstenite::Message::Text(target);
        ws_stream.send(msg).await?;

        // Create a DuplexStream and bridge WebSocket messages to/from it
        let (duplex_tx, duplex_rx) = tokio::io::duplex(8192);
        let ws = Arc::new(Mutex::new(ws_stream));

        // Spawn task to read from WebSocket and write to DuplexStream
        let ws_reader = ws.clone();
        let duplex_writer = duplex_tx;
        tokio::spawn(async move {
            let mut ws = ws_reader.lock().await;
            loop {
                match ws.next().await {
                    Some(Ok(msg)) => {
                        let data = msg.into_data();
                        if let Err(_) = duplex_writer.write_all(&data).await {
                            break;
                        }
                    }
                    _ => break,
                }
            }
        });

        // Spawn task to read from DuplexStream and write to WebSocket
        let mut duplex_reader = duplex_rx;
        let ws_writer = ws.clone();
        tokio::spawn(async move {
            let mut buf = vec![0u8; 8192];
            loop {
                match duplex_reader.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        let data = buf[..n].to_vec();
                        let msg = tokio_tungstenite::tungstenite::Message::Binary(data);
                        let mut ws = ws_writer.lock().await;
                        if let Err(_) = ws.send(msg).await {
                            break;
                        }
                    }
                }
            }
        });

        // Return the read half of the DuplexStream as a boxed AsyncReadWrite.
        // Actually we need both halves; we already moved duplex_tx. So we must return a single stream that is both.
        // But we split them; we can combine them into a JoinStream? Not needed. Instead we can return the
        // duplex_tx as the write half and duplex_rx as the read half, but they are separate objects.
        // A simpler solution: use tokio::io::split and return a wrapper.
        // However, for MVP we can use the DuplexStream directly if we don't split it before.
        // Let's refactor: keep the DuplexStream intact and spawn two tasks that forward data
        // between the DuplexStream and the WebSocket. Then return the DuplexStream itself.
        // That's easier: we already have duplex_tx and duplex_rx created, but duplex() returns a pair.
        // To keep it as one object, we can use the DuplexStream's halves? No, DuplexStream is bi-directional
        // by itself? Actually tokio::io::duplex returns a pair (DuplexStream, DuplexStream) where one is
        // the read/write for one side, and the other for the other side. So each half is both read+write.
        // We can use one half for the local side and the other half for the remote side (ws tasks).
        // That's perfect! Let's restructure:
        //   let (local, remote) = tokio::io::duplex(8192);
        //   Spawn tasks that pipe between ws_stream and remote.
        //   Return Box::new(local).
        // This way local implements AsyncRead+AsyncWrite and we avoid complex wrapping.
        // Let's implement that correctly now.
        
        // Correct implementation:
        let (local, remote) = tokio::io::duplex(8192);
        let ws = Arc::new(Mutex::new(ws_stream));
        
        // Copy from WebSocket to remote (write side)
        let ws_read = ws.clone();
        let remote_write = remote; // remote is a DuplexStream, we need to write into it
        // but we need to split remote into read/write halves to avoid ownership issues.
        // We can use tokio::io::split(remote) to get OwnedWriteHalf and OwnedReadHalf.
        // Let's do that.
        let (remote_reader, remote_writer) = tokio::io::split(remote);
        
        // Task 1: read from WebSocket, write to remote_writer
        tokio::spawn(async move {
            let mut ws = ws_read.lock().await;
            let mut writer = remote_writer;
            loop {
                match ws.next().await {
                    Some(Ok(msg)) => {
                        if let Err(_) = writer.write_all(&msg.into_data()).await {
                            break;
                        }
                    }
                    _ => break,
                }
            }
        });
        
        // Task 2: read from remote_reader, write to WebSocket
        let ws_write = ws.clone();
        tokio::spawn(async move {
            let mut reader = remote_reader;
            let mut ws = ws_write.lock().await;
            let mut buf = vec![0u8; 8192];
            loop {
                match reader.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        let msg = tokio_tungstenite::tungstenite::Message::Binary(buf[..n].to_vec());
                        if let Err(_) = ws.send(msg).await {
                            break;
                        }
                    }
                }
            }
        });
        
        Ok(Box::new(local))
    }
}