use anyhow::Result;
use pcap_file::{PcapWriter, PcapHeader};
use std::fs::File;
use std::io::BufWriter;
use std::path::Path;

pub struct SessionRecorder {
    writer: Option<PcapWriter<BufWriter<File>>>,
}

impl SessionRecorder {
    pub fn new(path: &Path) -> Result<Self> {
        let file = File::create(path)?;
        let writer = PcapWriter::new(
            PcapHeader {
                datalink: pcap_file::DataLink::ETHERNET,
                ..Default::default()
            },
            BufWriter::new(file),
        )?;
        Ok(Self { writer: Some(writer) })
    }

    pub fn record_packet(&mut self, data: &[u8]) -> Result<()> {
        if let Some(ref mut w) = self.writer {
            w.write_packet(
                std::time::SystemTime::now(),
                data.len() as u32,
                data,
            )?;
        }
        Ok(())
    }

    pub fn finish(&mut self) {
        self.writer.take();
    }
}