use anyhow::Result;

/// Experimental Encrypted Client Hello support.
pub struct EchClient;

impl EchClient {
    pub fn new() -> Self { Self }

    pub async fn enable(&self) -> Result<()> {
        // In future, integrate with rustls and DNS over HTTPS for ECH config
        log::warn!("ECH is not yet implemented. Requires server support.");
        Ok(())
    }
}