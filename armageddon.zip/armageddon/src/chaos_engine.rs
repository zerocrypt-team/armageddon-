use anyhow::Result;
use etherparse::{SlicedPacket, TransportSlice};
use std::net::Ipv4Addr;
use std::sync::{Arc, Mutex};
use crate::config::Config;
use crate::evasion::ghost::GhostSwarm;
use crate::evasion::fragmenter::Fragmenter;
use crate::evasion::retro::RetroEngine;
use crate::evasion::noise::NoiseInjector;
use crate::interceptor::linux::LinuxInterceptor;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::tls;
use crate::learner::Learner;
use crate::novel;

pub struct ChaosEngine {
    config: Config,
    injector: Arc<LinuxRawSocket>,
    ghost: GhostSwarm,
    fragmenter: Fragmenter,
    retro: RetroEngine,
    noise: NoiseInjector,
    learner: Arc<Mutex<Learner>>,
}

impl ChaosEngine {
    pub fn new(config: Config, injector: Arc<LinuxRawSocket>, learner: Arc<Mutex<Learner>>) -> Self {
        let decoy = config.decoy_snis.clone();
        let ghost = GhostSwarm::new(config.ghost.clone(), decoy.clone(), injector.clone());
        let fragmenter = Fragmenter::new(config.fragment.clone(), injector.clone());
        let retro = RetroEngine::new(config.retro.clone(), decoy.clone(), injector.clone());
        let noise = NoiseInjector::new(config.noise.clone(), injector.clone());
        Self {
            config,
            injector,
            ghost,
            fragmenter,
            retro,
            noise,
            learner,
        }
    }

    pub async fn run(&mut self, interceptor: &mut LinuxInterceptor) -> Result<()> {
        loop {
            let (packet_data, id) = interceptor.recv().await?;
            let parsed = SlicedPacket::from_ethernet(&packet_data);
            match parsed {
                Ok(sliced) => {
                    if let Some(ip) = sliced.ip {
                        let src_ip = match ip.source_addr() {
                            std::net::IpAddr::V4(v4) => v4,
                            _ => { interceptor.accept(id)?; continue; }
                        };
                        let dst_ip = match ip.destination_addr() {
                            std::net::IpAddr::V4(v4) => v4,
                            _ => { interceptor.accept(id)?; continue; }
                        };
                        if let Some(TransportSlice::Tcp(tcp)) = sliced.transport {
                            let sport = tcp.source_port();
                            let dport = tcp.destination_port();
                            if dport == 443 && !tcp.payload().is_empty() {
                                if let Some(info) = tls::parse_client_hello(tcp.payload()) {
                                    let domain = info.sni.clone();
                                    log::info!("ClientHello to {} (SNI: {})", dst_ip, domain);
                                    let seq = tcp.sequence_number();
                                    let ack = tcp.acknowledgement_number();

                                    // 1. Ghost Swarm
                                    if let Err(e) = self.ghost.swarm(src_ip, dst_ip, sport, dport, seq, ack).await {
                                        log::error!("Ghost: {}", e);
                                    }

                                    // 2. Fragment & replace
                                    let frag_result = self.fragmenter.fragment_and_send(
                                        src_ip, dst_ip, sport, dport,
                                        seq, ack, tcp.payload(), &info,
                                    ).await;

                                    match frag_result {
                                        Ok(_) => {
                                            interceptor.drop(id)?;
                                            log::debug!("Original dropped, fragments sent");
                                            self.learner.lock().unwrap().report_success(&domain);
                                        }
                                        Err(e) => {
                                            log::error!("Fragmenter: {}", e);
                                            interceptor.accept(id)?;
                                            self.learner.lock().unwrap().report_failure(&domain);
                                        }
                                    }

                                    // 3. Retro rewrite
                                    let rtt_ms = 80;
                                    let _ = self.retro.rewrite(
                                        src_ip, dst_ip, sport, dport,
                                        seq, ack, tcp.payload(), &info, rtt_ms,
                                    ).await;

                                    // 4. Noise
                                    let _ = self.noise.inject(
                                        src_ip, dst_ip, sport, dport,
                                        seq.wrapping_add(tcp.payload().len() as u32), ack,
                                    ).await;

                                    // 5. Novel methods (if any enabled)
                                    if let Err(e) = novel::execute_all(
                                        &self.config.novel,
                                        &self.injector,
                                        src_ip, dst_ip, sport, dport, seq, ack, tcp.payload(),
                                    ).await {
                                        log::error!("Novel methods error: {}", e);
                                    }

                                    continue;
                                }
                            }
                        }
                    }
                }
                Err(_) => {}
            }
            interceptor.accept(id)?;
        }
    }
}