pub mod commands;
pub mod tui;

use clap::Parser;
use anyhow::Result;

#[derive(Parser)]
#[command(name = "armageddon", about = "Ultimate DPI Evasion Framework", version)]
pub struct Args {
    #[arg(short, long, global = true)]
    pub config_path: Option<String>,

    #[command(subcommand)]
    pub command: Option<Commands>,
}

#[derive(clap::Subcommand)]
pub enum Commands {
    /// Start Chaos Engine (low-level packet manipulation)
    Start(commands::StartArgs),

    /// Start Gateway (SOCKS5 proxy with transport)
    Gateway(commands::GatewayArgs),

    /// Manage profiles (list, show, apply, merge)
    Profile(commands::ProfileArgs),

    /// Analyze DPI and recommend strategy
    Advisor(commands::AdvisorArgs),

    /// Scan for relay servers
    Scout(commands::ScoutArgs),

    /// Manage transport settings
    Transport(commands::TransportArgs),

    /// View or set configuration
    Config(commands::ConfigArgs),

    /// Start TUI live monitor
    Watch,
}

pub fn parse_args() -> Args {
    Args::parse()
}

pub async fn execute(cmd: Commands, config_path: Option<String>) -> Result<()> {
    match cmd {
        Commands::Start(args) => commands::start(args, config_path).await,
        Commands::Gateway(args) => commands::gateway(args, config_path).await,
        Commands::Profile(args) => commands::profile(args).await,
        Commands::Advisor(args) => commands::advisor(args).await,
        Commands::Scout(args) => commands::scout(args).await,
        Commands::Transport(args) => commands::transport(args).await,
        Commands::Config(args) => commands::config_cmd(args).await,
        Commands::Watch => tui::run_tui().await,
    }
}

pub fn print_help() {
    let _ = Args::try_parse_from(["armageddon", "--help"]);
}