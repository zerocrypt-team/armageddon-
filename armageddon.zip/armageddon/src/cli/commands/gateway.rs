use anyhow::Result;
use crate::config;
use crate::gateway::socks5::Socks5Server;
use crate::transport::{Transport, websocket::WebSocketTransport, shadowsocks::ShadowsocksTransport};
use crate::profiles::Profile;
use std::sync::Arc;
use tokio::signal;

#[derive(clap::Args)]
pub struct GatewayArgs {
    #[arg(short, long, default_value = "ws")]
    pub transport: String,

    #[arg(short, long)]
    pub relay: Option<String>,

    #[arg(short, long, default_value = "127.0.0.1:1080")]
    pub listen: String,

    #[arg(long)]
    pub password: Option<String>,

    #[arg(long, default_value = "aes-256-gcm")]
    pub method: String,

    /// Profile name to load config (including transport settings)
    #[arg(short, long)]
    pub profile: Option<String>,
}

pub async fn gateway(args: GatewayArgs, config_path: Option<String>) -> Result<()> {
    let mut config = config::load(config_path.as_deref())?;
    if let Some(profile_name) = &args.profile {
        let builtins = Profile::builtin();
        if let Some(prof) = builtins.into_iter().find(|p| &p.name == profile_name) {
            config = prof.config;
        }
    }

    let transport: Arc<dyn Transport> = match args.transport.as_str() {
        "ws" => {
            let url = args.relay.ok_or_else(|| anyhow::anyhow!("--relay required for ws"))?;
            Arc::new(WebSocketTransport::new(&url).await?)
        }
        "ss" => {
            let url = args.relay.ok_or_else(|| anyhow::anyhow!("--relay required for ss"))?;
            let password = args.password.ok_or_else(|| anyhow::anyhow!("Password required for ss"))?;
            Arc::new(ShadowsocksTransport::new(&url, &password, &args.method).await?)
        }
        _ => anyhow::bail!("Unsupported transport: {}", args.transport),
    };

    let addr: std::net::SocketAddr = args.listen.parse()?;
    let server = Socks5Server::new(addr, transport);
    let handle = tokio::spawn(async move {
        if let Err(e) = server.run().await {
            log::error!("Gateway error: {}", e);
        }
    });

    log::info!("Gateway listening on {} with transport {}", args.listen, args.transport);
    signal::ctrl_c().await?;
    handle.abort();
    Ok(())
}