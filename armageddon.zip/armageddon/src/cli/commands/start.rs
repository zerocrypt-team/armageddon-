use anyhow::Result;
use std::sync::{Arc, Mutex};
use tokio::signal;

use crate::config::{self, Config};
use crate::platform;
use crate::injector::linux::LinuxRawSocket; // will need generic selection
use crate::interceptor::linux::LinuxInterceptor;
use crate::chaos_engine::ChaosEngine;
use crate::learner::Learner;
use crate::profiles::Profile;
use std::path::PathBuf;

#[derive(clap::Args)]
pub struct StartArgs {
    #[arg(short, long)]
    pub profile: Option<String>,
}

pub async fn start(args: StartArgs, config_path: Option<String>) -> Result<()> {
    let mut config = config::load(config_path.as_deref())?;
    
    if let Some(profile_name) = &args.profile {
        let builtins = Profile::builtin();
        if let Some(prof) = builtins.into_iter().find(|p| &p.name == profile_name) {
            config = prof.config;
            log::info!("Loaded profile '{}'", profile_name);
        } else {
            anyhow::bail!("Profile '{}' not found", profile_name);
        }
    } else {
        log::info!("Starting with mode: {}", config.mode);
    }

    #[cfg(target_os = "linux")]
    platform::ensure_root()?;
    #[cfg(target_os = "windows")]
    platform::ensure_admin()?;

    let learner_db_path = dirs_next::home_dir().map(|mut p| {
        p.push(".armageddon");
        std::fs::create_dir_all(&p).ok();
        p.push("learner.db");
        p
    });
    let learner = Arc::new(Mutex::new(Learner::new(learner_db_path)));

    // Injector: select OS
    #[cfg(target_os = "linux")]
    let injector = Arc::new(LinuxRawSocket::new()?);
    #[cfg(target_os = "windows")]
    let injector = Arc::new(crate::injector::windows::WindowsRawSocket::new()?);

    // Interceptor: select OS
    #[cfg(target_os = "linux")]
    let mut interceptor = LinuxInterceptor::new(0)?;
    #[cfg(target_os = "windows")]
    let mut interceptor = crate::interceptor::windows::WindowsInterceptor::new()?;

    let mut engine = ChaosEngine::new(config, injector, learner);

    log::info!("Chaos Engine online. Intercepting TCP/443...");

    let engine_handle = tokio::spawn(async move {
        if let Err(e) = engine.run(&mut interceptor).await {
            log::error!("Engine error: {}", e);
        }
    });

    signal::ctrl_c().await?;
    log::info!("Shutting down...");
    engine_handle.abort();
    Ok(())
}