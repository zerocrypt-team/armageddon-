use anyhow::Result;
use crate::config;
use crate::advisor::{self, AnalysisResult};
use crate::profiles::Profile;

#[derive(clap::Args)]
pub struct AdvisorArgs {
    #[arg(long)]
    pub quick: bool,
    #[arg(long)]
    pub apply: Option<String>, // profile name to apply
}

pub async fn advisor(args: AdvisorArgs) -> Result<()> {
    let cfg = config::load(None)?;
    let result: AnalysisResult = advisor::run_analysis(&cfg, args.quick).await?;

    println!("=== DPI Advisor ===");
    println!("Detected DPI: {}", result.dpi_type);
    println!();

    for s in &result.strategies {
        println!("  {}: {} - {}", s.label, s.profile, s.description);
    }

    if let Some(profile_name) = &args.apply {
        let builtins = Profile::builtin();
        if let Some(prof) = builtins.into_iter().find(|p| &p.name == profile_name) {
            println!("\nApplying profile '{}'...", profile_name);
            // In a full integration, this would reload the engine config.
        } else {
            println!("Profile '{}' not found.", profile_name);
        }
    }
    Ok(())
}