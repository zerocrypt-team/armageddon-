use anyhow::Result;
use crate::config;

#[derive(clap::Args)]
pub struct ConfigArgs {
    /// Show entire config
    #[arg(long)]
    pub show: bool,
    /// Set a config value (key=value)
    #[arg(long)]
    pub set: Option<String>,
}

pub async fn config_cmd(args: ConfigArgs) -> Result<()> {
    if args.show {
        let cfg = config::load(None)?;
        println!("Current configuration:\n{:#?}", cfg);
    } else if let Some(kv) = args.set {
        println!("Config set '{}' (not persisted yet)", kv);
    } else {
        println!("Use --show or --set");
    }
    Ok(())
}