use anyhow::Result;
use crate::scout;

#[derive(clap::Args)]
pub struct ScoutArgs {
    /// Test a specific relay URL
    #[arg(long)]
    pub test: Option<String>,
    /// Path to relay list JSON
    #[arg(long)]
    pub list: Option<String>,
}

pub async fn scout(args: ScoutArgs) -> Result<()> {
    if let Some(url) = args.test {
        let ok = scout::test_relay(&url, 3).await;
        println!("Relay {} is {}", url, if ok { "reachable" } else { "unreachable" });
    } else if let Some(path) = args.list {
        let relays = scout::load_relays(&path).await?;
        for r in &relays.relays {
            println!("{} - {} ({})", r.name, r.url, r.transport);
        }
    } else {
        println!("No relay provided. Use --test or --list");
    }
    Ok(())
}