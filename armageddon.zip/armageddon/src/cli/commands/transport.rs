use anyhow::Result;

#[derive(clap::Args)]
pub struct TransportArgs {
    #[command(subcommand)]
    pub action: TransportAction,
}

#[derive(clap::Subcommand)]
pub enum TransportAction {
    /// Set active transport
    Set {
        #[arg(short, long)]
        transport: String,
        #[arg(short, long)]
        relay: String,
    },
    /// Show current transport status
    Status,
}

pub async fn transport(args: TransportArgs) -> Result<()> {
    match args.action {
        TransportAction::Set { transport, relay } => {
            println!("Transport set to {} with relay {} (stub)", transport, relay);
        }
        TransportAction::Status => {
            println!("Current transport: none (Gateway not running)");
        }
    }
    Ok(())
}