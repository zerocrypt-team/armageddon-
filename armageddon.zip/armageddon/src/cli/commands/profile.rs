use anyhow::Result;
use crate::profiles::{Profile, merge};

#[derive(clap::Args)]
pub struct ProfileArgs {
    #[command(subcommand)]
    pub action: ProfileAction,
}

#[derive(clap::Subcommand)]
pub enum ProfileAction {
    /// List built‑in profiles
    List,
    /// Show details of a profile
    Show { name: String },
    /// Apply a profile (loads config, no runtime effect yet)
    Apply { name: String },
    /// Merge two profiles into a new one and show it
    Merge {
        first: String,
        second: String,
        #[arg(long)]
        output: Option<String>,
    },
}

pub async fn profile(args: ProfileArgs) -> Result<()> {
    match args.action {
        ProfileAction::List => {
            let builtins = Profile::builtin();
            println!("Built‑in profiles:");
            for p in builtins {
                println!("  - {}", p.name);
            }
        }
        ProfileAction::Show { name } => {
            let builtins = Profile::builtin();
            if let Some(prof) = builtins.into_iter().find(|p| p.name == name) {
                println!("{:#?}", prof.config);
            } else {
                println!("Profile '{}' not found", name);
            }
        }
        ProfileAction::Apply { name } => {
            let builtins = Profile::builtin();
            if builtins.iter().any(|p| p.name == name) {
                log::info!("Profile '{}' applied (config loaded)", name);
            } else {
                println!("Profile '{}' not found", name);
            }
        }
        ProfileAction::Merge { first, second, output } => {
            let builtins = Profile::builtin();
            let primary = builtins.iter().find(|p| p.name == first);
            let secondary = builtins.iter().find(|p| p.name == second);
            match (primary, secondary) {
                (Some(p), Some(s)) => {
                    let merged = merge::merge(p, s);
                    println!("Merged profile:\n{:#?}", merged.config);
                    if let Some(path) = output {
                        // Save to file
                        let toml_str = toml::to_string_pretty(&merged.config)?;
                        std::fs::write(&path, toml_str)?;
                        println!("Saved to {}", path);
                    }
                }
                _ => println!("One or both profiles not found."),
            }
        }
    }
    Ok(())
}