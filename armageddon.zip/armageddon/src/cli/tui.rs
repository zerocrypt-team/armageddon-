use anyhow::Result;
use crossterm::{
    event::{self, DisableMouseCapture, EnableMouseCapture, Event, KeyCode, KeyEventKind},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{
    prelude::*,
    widgets::*,
};
use std::io;
use std::time::{Duration, Instant};

pub async fn run_tui() -> Result<()> {
    // setup terminal
    enable_raw_mode()?;
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen, EnableMouseCapture)?;
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;

    let res = run_app(&mut terminal).await;

    // restore terminal
    disable_raw_mode()?;
    execute!(
        terminal.backend_mut(),
        LeaveAlternateScreen,
        DisableMouseCapture
    )?;
    terminal.show_cursor()?;

    if let Err(err) = res {
        println!("TUI error: {:?}", err);
    }
    Ok(())
}

async fn run_app<B: Backend>(terminal: &mut Terminal<B>) -> io::Result<()> {
    let mut last_tick = Instant::now();
    let mut packets = 0u64;
    let mut success_rate = 98.7;
    loop {
        terminal.draw(|f| {
            let size = f.size();
            let chunks = Layout::default()
                .direction(Direction::Vertical)
                .margin(2)
                .constraints(
                    [
                        Constraint::Length(3),
                        Constraint::Length(3),
                        Constraint::Min(0),
                    ]
                    .as_ref(),
                )
                .split(size);

            let title = Paragraph::new("☠️  ARMAFGEDDON TUI  |  Role: MASTER  |  Uptime: 4h 12m")
                .style(Style::default().fg(Color::Yellow).bold())
                .block(Block::default().borders(Borders::ALL).title("Dashboard"));
            f.render_widget(title, chunks[0]);

            let stats = Paragraph::new(format!(
                "Profile: Apocalypse | Gateway: 127.0.0.1:1080 | Transport: WebSocket (healthy) | RTT: 67ms | DPI: StatefulTCP"
            ))
            .style(Style::default().fg(Color::Green));
            f.render_widget(stats, chunks[1]);

            let gauge = Gauge::default()
                .block(Block::default().borders(Borders::ALL).title("Success Rate"))
                .gauge_style(Style::default().fg(Color::Cyan))
                .percent(success_rate as u16);
            let events = List::new(vec![
                "14:32:01 [WARN] DPI probe detected new RST pattern",
                "14:32:00 [OK] Ghost Swarm sent 12 decoys to google.com",
                "14:31:58 [INFO] Handshake complete: discord.com (TLS 1.3)",
            ])
            .block(Block::default().borders(Borders::ALL).title("Live Events"));

            let right_chunks = Layout::default()
                .direction(Direction::Horizontal)
                .constraints([Constraint::Percentage(50), Constraint::Percentage(50)].as_ref())
                .split(chunks[2]);

            f.render_widget(gauge, right_chunks[0]);
            f.render_widget(events, right_chunks[1]);
        })?;

        if event::poll(Duration::from_millis(100))? {
            if let Event::Key(key) = event::read()? {
                if key.kind == KeyEventKind::Press && key.code == KeyCode::Char('q') {
                    return Ok(());
                }
            }
        }

        // Simulate dynamic data
        if last_tick.elapsed() >= Duration::from_secs(1) {
            packets += 1;
            success_rate = 98.7 + (packets % 10) as f64 * 0.1;
            last_tick = Instant::now();
        }
    }
}