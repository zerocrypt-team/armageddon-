use anyhow::Result;

/// Reduce process priority and hide from casual observation.
pub fn enable_stealth_mode() -> Result<()> {
    #[cfg(target_os = "linux")]
    {
        // Set nice value to +10
        unsafe { libc::nice(10); }
        // Change process name (requires write to /proc/self/comm)
        if let Ok(mut f) = std::fs::File::create("/proc/self/comm") {
            use std::io::Write;
            let _ = f.write_all(b"armageddon");
        }
        log::info!("Stealth mode enabled (Linux)");
    }
    #[cfg(target_os = "windows")]
    {
        // Set priority class to BELOW_NORMAL
        // Not implemented yet
        log::warn!("Stealth mode not fully implemented on Windows");
    }
    Ok(())
}