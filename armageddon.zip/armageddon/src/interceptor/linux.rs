use anyhow::Result;
use nfqueue::{Queue, Verdict, CopyMode};
use std::sync::{Arc, Mutex};

pub struct LinuxInterceptor {
    queue: Arc<Mutex<Queue>>,
}

impl LinuxInterceptor {
    pub fn new(queue_num: u16) -> Result<Self> {
        let mut queue = Queue::open()?;
        queue.bind(queue_num)?;
        queue.set_copy_mode(CopyMode::PacketCopy)?;
        Ok(Self {
            queue: Arc::new(Mutex::new(queue)),
        })
    }

    pub async fn recv(&mut self) -> Result<(Vec<u8>, u32)> {
        let queue_clone = self.queue.clone();
        tokio::task::spawn_blocking(move || {
            let mut q = queue_clone.lock().unwrap();
            let msg = q.recv()?;
            let data = Vec::from(msg.get_payload());
            let id = msg.get_id();
            Ok::<_, anyhow::Error>((data, id))
        })
        .await?
    }

    pub fn accept(&self, id: u32) -> Result<()> {
        let q = self.queue.lock().unwrap();
        q.verdict(id, Verdict::Accept)?;
        Ok(())
    }

    pub fn drop(&self, id: u32) -> Result<()> {
        let q = self.queue.lock().unwrap();
        q.verdict(id, Verdict::Drop)?;
        Ok(())
    }
}