#[derive(Debug, Clone)]
pub enum Message {
    // Navigation
    SelectTab(Tab),
    // Profile actions
    SelectProfile(String),
    ApplyProfile,
    MergeProfiles(String, String),
    // Advisor
    RunAdvisorAnalysis(bool), // quick=true/false
    ApplyStrategy(String),
    // Transport
    StartGateway,
    StopGateway,
    // Config changes (expert tab)
    UpdateGhostEnabled(bool),
    UpdateGhostMinCount(usize),
    // ... more fields
    // Simulation tick (will be replaced by real data later)
    Tick,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Tab {
    Dashboard,
    Profiles,
    Expert,
    Advisor,
    Transport,
    Logs,
}