use eframe::egui::{self, Context};
use crate::gui::message::{Message, Tab};
use crate::gui::views::{dashboard, profiles, expert, advisor, transport, logs};

pub struct ArmageddonApp {
    current_tab: Tab,
    // Temporary state for GUI demonstration
    ghost_enabled: bool,
    ghost_min_count: usize,
    // ... more state
    logs: Vec<String>,
    selected_profile: String,
}

impl ArmageddonApp {
    pub fn new() -> Self {
        Self {
            current_tab: Tab::Dashboard,
            ghost_enabled: true,
            ghost_min_count: 3,
            logs: vec![
                "14:32:01 [WARN] DPI probe detected new RST pattern".into(),
                "14:32:00 [OK] Ghost Swarm sent 12 decoys to google.com".into(),
                "14:31:58 [INFO] Handshake complete: discord.com (TLS 1.3)".into(),
            ],
            selected_profile: "apocalypse".into(),
        }
    }

    pub fn update(&mut self, ctx: &Context, msg: Message) {
        match msg {
            Message::SelectTab(tab) => {
                self.current_tab = tab;
            }
            Message::SelectProfile(name) => {
                self.selected_profile = name;
            }
            Message::ApplyProfile => {
                self.logs.push(format!("Applied profile: {}", self.selected_profile));
            }
            Message::RunAdvisorAnalysis(quick) => {
                let kind = if quick { "quick" } else { "full" };
                self.logs.push(format!("Advisor analysis ({}) started...", kind));
                // Simulate result
                self.logs.push("Detected DPI: StatefulTCP + DeepTLS".into());
            }
            Message::ApplyStrategy(name) => {
                self.logs.push(format!("Applied strategy: {}", name));
            }
            Message::UpdateGhostEnabled(val) => {
                self.ghost_enabled = val;
            }
            Message::UpdateGhostMinCount(val) => {
                self.ghost_min_count = val;
            }
            Message::Tick => {
                // In future, update live stats from engine
            }
            _ => {}
        }
        ctx.request_repaint();
    }
}

impl eframe::App for ArmageddonApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Top panel with tabs
        egui::TopBottomPanel::top("tab_bar").show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.selectable_value(&mut self.current_tab, Tab::Dashboard, "📊 Dashboard");
                ui.selectable_value(&mut self.current_tab, Tab::Profiles, "🎭 Profiles");
                ui.selectable_value(&mut self.current_tab, Tab::Expert, "⚙️ Expert");
                ui.selectable_value(&mut self.current_tab, Tab::Advisor, "🧠 Advisor");
                ui.selectable_value(&mut self.current_tab, Tab::Transport, "🚇 Transport");
                ui.selectable_value(&mut self.current_tab, Tab::Logs, "📜 Logs");
            });
        });

        // Central content
        egui::CentralPanel::default().show(ctx, |ui| {
            match self.current_tab {
                Tab::Dashboard => dashboard::show(ui, self),
                Tab::Profiles => profiles::show(ui, self),
                Tab::Expert => expert::show(ui, self),
                Tab::Advisor => advisor::show(ui, self),
                Tab::Transport => transport::show(ui, self),
                Tab::Logs => logs::show(ui, self),
            }
        });

        // Periodic update (simulate live data)
        ctx.request_repaint_after(std::time::Duration::from_secs(2));
    }
}