pub mod app;
pub mod message;
pub mod views;

use anyhow::Result;
use eframe::egui;

pub async fn run_gui() -> Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1024.0, 768.0]),
        ..Default::default()
    };
    eframe::run_native(
        "Armageddon – DPI Evasion Framework",
        options,
        Box::new(|_cc| {
            let app = app::ArmageddonApp::new();
            Ok(Box::new(app))
        }),
    )?;
    Ok(())
}