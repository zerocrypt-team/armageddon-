use egui::Ui;
use crate::gui::app::ArmageddonApp;

pub fn show(ui: &mut Ui, _app: &ArmageddonApp) {
    ui.heading("🚇 Transport");
    ui.separator();
    ui.label("Current transport: WebSocket (healthy)");
    ui.add_space(10.0);
    ui.horizontal(|ui| {
        if ui.button("Start Gateway").clicked() {
            // Message::StartGateway
        }
        if ui.button("Stop Gateway").clicked() {
            // Message::StopGateway
        }
    });
    ui.add_space(10.0);
    ui.label("Relay: wss://relay.example.com:443");
    ui.label("Listen: 127.0.0.1:1080");
}