use egui::Ui;
use crate::gui::app::ArmageddonApp;

pub fn show(ui: &mut Ui, app: &ArmageddonApp) {
    ui.heading("📜 Logs");
    ui.separator();
    egui::ScrollArea::vertical()
        .max_height(ui.available_height() - 30.0)
        .show(ui, |ui| {
            for log in &app.logs {
                ui.label(log);
            }
        });
    if ui.button("Clear Logs").clicked() {
        // message to clear logs
    }
}