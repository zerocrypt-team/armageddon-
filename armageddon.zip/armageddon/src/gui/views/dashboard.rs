use egui::{Context, Ui};
use crate::gui::app::ArmageddonApp;

pub fn show(ui: &mut Ui, _app: &ArmageddonApp) {
    ui.heading("📊 Dashboard");
    ui.separator();

    ui.label("Profile: Apocalypse (active)");
    ui.label("Gateway: 127.0.0.1:1080  |  Transport: WebSocket (healthy)");
    ui.label("RTT: 67ms  |  DPI Type: StatefulTCP/DeepTLS  |  Stealth: MAX");

    ui.add_space(10.0);

    ui.horizontal(|ui| {
        ui.vertical(|ui| {
            ui.label("Throughput");
            // Use a simple progress bar instead of plot for MVP
            ui.add(egui::ProgressBar::new(0.89).text("12.4 MB/s"));
        });
        ui.vertical(|ui| {
            ui.label("Packets processed: 142K");
            ui.add(egui::ProgressBar::new(0.987).text("98.7% success"));
        });
    });

    ui.add_space(10.0);

    ui.collapsing("Active Methods", |ui| {
        ui.label("[✓] Ghost Swarm (7-12 pkts)");
        ui.label("[✓] IP Fragmentation (4 segs)");
        ui.label("[✓] Temporal Rewind");
        ui.label("[✓] uTLS (Chrome 124)");
        ui.label("[✓] Novel: URG, ALPN, SACK");
        ui.label("[✓] DSCP Confusion");
    });

    ui.separator();
    ui.heading("Live Events");
    // Show last few logs
    for log in _app.logs.iter().rev().take(5) {
        ui.label(log);
    }
}