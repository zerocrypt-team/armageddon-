use egui::Ui;
use crate::gui::app::ArmageddonApp;
use crate::gui::message::Message;
use crate::profiles::Profile;

pub fn show(ui: &mut Ui, app: &mut ArmageddonApp) {
    ui.heading("🎭 Profiles");
    ui.separator();

    let builtins = Profile::builtin();
    let current = app.selected_profile.clone();

    ui.horizontal(|ui| {
        ui.label("Select profile:");
        egui::ComboBox::from_id_source("profile_selector")
            .selected_text(&current)
            .show_ui(ui, |ui| {
                for p in builtins {
                    ui.selectable_value(
                        &mut app.selected_profile,
                        p.name.clone(),
                        &p.name,
                    );
                }
            });
    });

    if ui.button("Apply Profile").clicked() {
        app.update(ui.ctx(), Message::ApplyProfile);
    }

    ui.add_space(10.0);
    ui.label("Merge two profiles:");
    ui.horizontal(|ui| {
        let mut first = "apocalypse".to_string();
        let mut second = "ghost-rider".to_string();
        ui.text_edit_singleline(&mut first);
        ui.label("+");
        ui.text_edit_singleline(&mut second);
        if ui.button("Merge").clicked() {
            app.update(ui.ctx(), Message::MergeProfiles(first, second));
        }
    });
}