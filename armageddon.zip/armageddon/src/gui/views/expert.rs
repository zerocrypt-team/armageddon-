use egui::Ui;
use crate::gui::app::ArmageddonApp;
use crate::gui::message::Message;

pub fn show(ui: &mut Ui, app: &mut ArmageddonApp) {
    ui.heading("⚙️ Expert Settings");
    ui.separator();

    ui.collapsing("Ghost Swarm", |ui| {
        ui.checkbox(&mut app.ghost_enabled, "Enabled");
        if app.ghost_enabled {
            ui.add(egui::Slider::new(&mut app.ghost_min_count, 1..=20).text("Min count"));
        }
    });

    ui.collapsing("Fragmentation", |ui| {
        ui.label("(params to be added)");
    });

    // ... other collapsings for Retro, Noise, Novel
    if ui.button("Save changes").clicked() {
        // send message to update config
    }
}