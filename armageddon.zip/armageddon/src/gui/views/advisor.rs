use egui::Ui;
use crate::gui::app::ArmageddonApp;
use crate::gui::message::Message;

pub fn show(ui: &mut Ui, app: &mut ArmageddonApp) {
    ui.heading("🧠 DPI Advisor");
    ui.separator();

    ui.horizontal(|ui| {
        if ui.button("Quick Analysis").clicked() {
            app.update(ui.ctx(), Message::RunAdvisorAnalysis(true));
        }
        if ui.button("Full Analysis").clicked() {
            app.update(ui.ctx(), Message::RunAdvisorAnalysis(false));
        }
    });

    ui.add_space(10.0);
    ui.label("Simulated result:");
    ui.label("Detected DPI: StatefulTCP + DeepTLS");

    ui.collapsing("Strategies", |ui| {
        if ui.button("Apply Fast (fragment-king)").clicked() {
            app.update(ui.ctx(), Message::ApplyStrategy("fragment-king".into()));
        }
        if ui.button("Apply Balanced (stealth-combo)").clicked() {
            app.update(ui.ctx(), Message::ApplyStrategy("stealth-combo".into()));
        }
        if ui.button("Apply Guaranteed (apocalypse)").clicked() {
            app.update(ui.ctx(), Message::ApplyStrategy("apocalypse".into()));
        }
    });
}