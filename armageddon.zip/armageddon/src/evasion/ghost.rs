use anyhow::Result;
use rand::Rng;
use std::net::Ipv4Addr;
use std::sync::Arc;
use crate::config::GhostConfig;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::{tcp, ip, tls};

pub struct GhostSwarm {
    config: GhostConfig,
    decoy_snis: Vec<String>,
    injector: Arc<LinuxRawSocket>,
}

impl GhostSwarm {
    pub fn new(config: GhostConfig, decoy_snis: Vec<String>, injector: Arc<LinuxRawSocket>) -> Self {
        Self { config, decoy_snis, injector }
    }

    pub async fn swarm(
        &self,
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        src_port: u16,
        dst_port: u16,
        real_seq: u32,
        real_ack: u32,
    ) -> Result<()> {
        if !self.config.enabled {
            return Ok(());
        }
        let mut rng = rand::thread_rng();
        let count = rng.gen_range(self.config.min_count..=self.config.max_count);

        for _ in 0..count {
            let sni = &self.decoy_snis[rng.gen_range(0..self.decoy_snis.len())];
            let payload = tls::build_fake_client_hello(sni, &mut rng)?;

            let ttl = rng.gen_range(self.config.ttl_min..=self.config.ttl_max);
            let seq = real_seq.wrapping_add(rng.gen_range(self.config.seq_offset_min..=self.config.seq_offset_max));
            let tos = rng.gen_range(0..64);
            let window = if rng.gen_bool(self.config.zero_window_prob) {
                0
            } else {
                rng.gen_range(1024..65535)
            };
            let urg = rng.gen_bool(self.config.urg_prob);
            let flags = if urg { 0x20 } else { 0x10 };

            let tcp_pkt = tcp::build_tcp_packet(
                src_ip,
                dst_ip,
                &tcp::TcpOptions {
                    seq,
                    ack: real_ack,
                    sport: src_port,
                    dport: dst_port,
                    window,
                    flags,
                    urg,
                    urg_ptr: if urg { rng.gen() } else { 0 },
                    timestamp: None,
                },
                &payload,
            )?;

            let header_hide = rng.gen_bool(self.config.header_hide_prob);
            ip::send_tcp_via_ip(
                &self.injector,
                src_ip,
                dst_ip,
                &tcp_pkt,
                ttl,
                rng.gen(),
                tos,
                header_hide,
            )
            .await?;

            tokio::time::sleep(std::time::Duration::from_micros(rng.gen_range(100..500))).await;
        }
        Ok(())
    }
}