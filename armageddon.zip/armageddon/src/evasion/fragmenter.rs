use anyhow::Result;
use rand::Rng;
use std::net::Ipv4Addr;
use std::sync::Arc;
use crate::config::FragmentConfig;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::{ip, tcp, tls, grease};

pub struct Fragmenter {
    config: FragmentConfig,
    injector: Arc<LinuxRawSocket>,
}

impl Fragmenter {
    pub fn new(config: FragmentConfig, injector: Arc<LinuxRawSocket>) -> Self {
        Self { config, injector }
    }

    pub async fn fragment_and_send(
        &self,
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        src_port: u16,
        dst_port: u16,
        seq: u32,
        ack: u32,
        original_payload: &[u8],
        info: &tls::ClientHelloInfo,
    ) -> Result<u32> {
        if !self.config.enabled {
            let tcp_pkt = tcp::build_tcp_packet(
                src_ip, dst_ip,
                &tcp::TcpOptions {
                    seq, ack, sport: src_port, dport: dst_port,
                    window: 65535, flags: 0x18, urg: false, urg_ptr: 0, timestamp: None,
                },
                original_payload,
            )?;
            ip::send_tcp_via_ip(&self.injector, src_ip, dst_ip, &tcp_pkt, 64, rand::thread_rng().gen(), 0, false).await?;
            return Ok(seq + original_payload.len() as u32);
        }

        let mut rng = rand::thread_rng();
        let mut mod_payload = original_payload.to_vec();

        if self.config.grease_enabled {
            let grease_ext = grease::generate_grease_extension(&mut rng, self.config.grease_size_min, self.config.grease_size_max);
            mod_payload.extend_from_slice(&grease_ext);
        }

        let frag_count = rng.gen_range(self.config.min_frags..=self.config.max_frags);
        if frag_count <= 1 || mod_payload.len() < 2 {
            let tcp_pkt = tcp::build_tcp_packet(
                src_ip, dst_ip,
                &tcp::TcpOptions {
                    seq, ack, sport: src_port, dport: dst_port,
                    window: 65535, flags: 0x18, urg: false, urg_ptr: 0, timestamp: None,
                },
                &mod_payload,
            )?;
            ip::send_tcp_via_ip(&self.injector, src_ip, dst_ip, &tcp_pkt, 64, rng.gen(), 0, false).await?;
            return Ok(seq + mod_payload.len() as u32);
        }

        let payload_len = mod_payload.len();
        let sni_region = if self.config.sn_safe && !info.sni.is_empty() {
            Some((info.sni_start, info.sni_start + info.sni_len))
        } else {
            None
        };

        let mut splits = Vec::new();
        let mut last = 0;
        for _ in 0..(frag_count - 1) {
            if last >= payload_len.saturating_sub(1) { break; }
            let max_pos = payload_len - 1;
            let mut pos = rng.gen_range(last + 1..=max_pos);
            if let Some((s_start, s_end)) = sni_region {
                if pos > s_start && pos < s_end {
                    pos = if rng.gen_bool(0.5) { s_start } else { s_end };
                }
            }
            splits.push(pos);
            last = pos;
        }
        splits.sort();

        let mut next_seq = seq;
        let mut prev_end = 0;
        for &end in &splits {
            let piece = &mod_payload[prev_end..end];
            let tcp_pkt = tcp::build_tcp_packet(
                src_ip, dst_ip,
                &tcp::TcpOptions {
                    seq: next_seq, ack, sport: src_port, dport: dst_port,
                    window: 65535, flags: 0x18, urg: false, urg_ptr: 0, timestamp: None,
                },
                piece,
            )?;
            ip::send_tcp_via_ip(&self.injector, src_ip, dst_ip, &tcp_pkt, 64, rng.gen(), 0, false).await?;
            next_seq += piece.len() as u32;
            prev_end = end;
            tokio::time::sleep(std::time::Duration::from_micros(rng.gen_range(200..1500))).await;
        }
        if prev_end < payload_len {
            let piece = &mod_payload[prev_end..];
            let tcp_pkt = tcp::build_tcp_packet(
                src_ip, dst_ip,
                &tcp::TcpOptions {
                    seq: next_seq, ack, sport: src_port, dport: dst_port,
                    window: 65535, flags: 0x18, urg: false, urg_ptr: 0, timestamp: None,
                },
                piece,
            )?;
            ip::send_tcp_via_ip(&self.injector, src_ip, dst_ip, &tcp_pkt, 64, rng.gen(), 0, false).await?;
            next_seq += piece.len() as u32;
        }
        Ok(next_seq)
    }
}