use anyhow::Result;
use rand::Rng;
use std::net::Ipv4Addr;
use std::sync::Arc;
use crate::config::NoiseConfig;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::{tcp, ip};

pub struct NoiseInjector {
    config: NoiseConfig,
    injector: Arc<LinuxRawSocket>,
}

impl NoiseInjector {
    pub fn new(config: NoiseConfig, injector: Arc<LinuxRawSocket>) -> Self {
        Self { config, injector }
    }

    pub async fn inject(
        &self,
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        src_port: u16,
        dst_port: u16,
        base_seq: u32,
        ack: u32,
    ) -> Result<u32> {
        if !self.config.enabled {
            return Ok(base_seq);
        }
        let mut rng = rand::thread_rng();
        let count = rng.gen_range(self.config.min_count..=self.config.max_count);
        let mut next_seq = base_seq;
        for _ in 0..count {
            let payload_len = rng.gen_range(10..60);
            let payload: Vec<u8> = (0..payload_len).map(|_| rng.gen()).collect();
            let tcp_pkt = tcp::build_tcp_packet(
                src_ip, dst_ip,
                &tcp::TcpOptions {
                    seq: next_seq, ack,
                    sport: src_port, dport: dst_port,
                    window: 65535, flags: 0x18, urg: false, urg_ptr: 0, timestamp: None,
                },
                &payload,
            )?;
            ip::send_tcp_via_ip(&self.injector, src_ip, dst_ip, &tcp_pkt, 1, rng.gen(), 0, false).await?;
            next_seq += payload_len as u32;
            tokio::time::sleep(std::time::Duration::from_micros(rng.gen_range(50..200))).await;
        }
        Ok(next_seq)
    }
}