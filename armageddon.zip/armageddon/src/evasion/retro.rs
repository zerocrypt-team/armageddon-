use anyhow::Result;
use rand::Rng;
use std::net::Ipv4Addr;
use std::sync::Arc;
use std::time::SystemTime;
use crate::config::RetroConfig;
use crate::injector::linux::LinuxRawSocket;
use crate::packet_builder::{tcp, ip, tls};

pub struct RetroEngine {
    config: RetroConfig,
    decoy_snis: Vec<String>,
    injector: Arc<LinuxRawSocket>,
}

impl RetroEngine {
    pub fn new(config: RetroConfig, decoy_snis: Vec<String>, injector: Arc<LinuxRawSocket>) -> Self {
        Self { config, decoy_snis, injector }
    }

    pub async fn rewrite(
        &self,
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        src_port: u16,
        dst_port: u16,
        original_seq: u32,
        ack: u32,
        _payload: &[u8],
        _info: &tls::ClientHelloInfo,
        rtt_ms: u64,
    ) -> Result<()> {
        if !self.config.enabled || rtt_ms <= self.config.rtt_threshold_ms {
            return Ok(());
        }
        let mut rng = rand::thread_rng();
        if !rng.gen_bool(self.config.probability) {
            return Ok(());
        }

        let sni = &self.decoy_snis[rng.gen_range(0..self.decoy_snis.len())];
        let fake_hello = tls::build_fake_client_hello(sni, &mut rng)?;

        let now = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap()
            .as_micros() as u32;
        let ts = if self.config.use_timestamp {
            Some(now.wrapping_add((rtt_ms as u64 * 2000) as u32))
        } else {
            None
        };

        let tcp_pkt = tcp::build_tcp_packet(
            src_ip,
            dst_ip,
            &tcp::TcpOptions {
                seq: original_seq,
                ack,
                sport: src_port,
                dport: dst_port,
                window: 65535,
                flags: 0x18,
                urg: false,
                urg_ptr: 0,
                timestamp: ts,
            },
            &fake_hello,
        )?;

        ip::send_tcp_via_ip(&self.injector, src_ip, dst_ip, &tcp_pkt, 2, rng.gen(), 0, false).await?;
        Ok(())
    }
}