use serde::{Deserialize, Serialize};
use anyhow::Result;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub mode: String,
    pub decoy_snis: Vec<String>,
    pub gateway_addr: String,
    pub ghost: GhostConfig,
    pub fragment: FragmentConfig,
    pub retro: RetroConfig,
    pub noise: NoiseConfig,
    pub utls: UtlsConfig,
    pub novel: NovelConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GhostConfig {
    pub enabled: bool,
    pub min_count: usize,
    pub max_count: usize,
    pub ttl_min: u8,
    pub ttl_max: u8,
    pub seq_offset_min: u32,
    pub seq_offset_max: u32,
    pub header_hide_prob: f64,
    pub urg_prob: f64,
    pub zero_window_prob: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FragmentConfig {
    pub enabled: bool,
    pub min_frags: usize,
    pub max_frags: usize,
    pub grease_enabled: bool,
    pub grease_size_min: usize,
    pub grease_size_max: usize,
    pub sn_safe: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RetroConfig {
    pub enabled: bool,
    pub probability: f64,
    pub rtt_threshold_ms: u64,
    pub use_timestamp: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NoiseConfig {
    pub enabled: bool,
    pub min_count: usize,
    pub max_count: usize,
    pub delay_shape: f64,
    pub delay_scale: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UtlsConfig {
    pub enabled: bool,
    pub profile: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NovelConfig {
    pub urg_diversion: bool,
    pub sack_spoofing: bool,
    pub alpn_randomization: bool,
    pub fin_bomb: bool,
    pub dscp_confusion: bool,
    pub timestamp_side_channel: bool,
    pub window_pattern: bool,
    pub ecn_toggle: bool,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            mode: "apocalypse".into(),
            decoy_snis: vec![
                "www.google.com".into(),
                "www.cloudflare.com".into(),
                "www.microsoft.com".into(),
                "www.apple.com".into(),
                "www.youtube.com".into(),
            ],
            gateway_addr: "127.0.0.1:1080".into(),
            ghost: GhostConfig {
                enabled: true,
                min_count: 3,
                max_count: 8,
                ttl_min: 1,
                ttl_max: 3,
                seq_offset_min: 2000,
                seq_offset_max: 20000,
                header_hide_prob: 0.3,
                urg_prob: 0.2,
                zero_window_prob: 0.1,
            },
            fragment: FragmentConfig {
                enabled: true,
                min_frags: 3,
                max_frags: 5,
                grease_enabled: true,
                grease_size_min: 50,
                grease_size_max: 200,
                sn_safe: true,
            },
            retro: RetroConfig {
                enabled: true,
                probability: 0.8,
                rtt_threshold_ms: 50,
                use_timestamp: true,
            },
            noise: NoiseConfig {
                enabled: true,
                min_count: 1,
                max_count: 3,
                delay_shape: 1.5,
                delay_scale: 800.0,
            },
            utls: UtlsConfig {
                enabled: false,
                profile: None,
            },
            novel: NovelConfig {
                urg_diversion: false,
                sack_spoofing: false,
                alpn_randomization: false,
                fin_bomb: false,
                dscp_confusion: false,
                timestamp_side_channel: false,
                window_pattern: false,
                ecn_toggle: false,
            },
        }
    }
}

pub fn load(path: Option<&str>) -> Result<Config> {
    match path {
        Some(p) => {
            let content = std::fs::read_to_string(p)?;
            Ok(toml::from_str(&content)?)
        }
        None => Ok(Config::default()),
    }
}