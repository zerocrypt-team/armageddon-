pub const BANNER: &str = r#"
      ▄███████▄     ████████▄   ██████████   ███████████  
      ██      ██    ██     ██   ██           ██       ██ 
      ██      ██    ██     ██   ██           ██       ██ 
      █████████▀    ████████▀   ████████     ██       ██ 
      ██            ███████    ██           ██       ██ 
      ██            ██     ██  ██           ██       ██ 
      ██            ██      ██ ██████████   ███████████ 
                                                       
     ☠️  A R M A G E D D O N  ☠️
     The Ultimate DPI Evasion Framework
     Version 1.0.0 – Rust Edition

━━━━━━━━━━━━  T E A M   Z E R O C R Y P T  ━━━━━━━━━━━━

  Security:
    Armita, Ashkan, Artemis, Selena, Maede, Mozhgan, Atosa

  Development:
    Ali, Alireza, Setare

  Network Programming:
    Armita, Ashkan

  Networking:
    Ashkan, Mamad, Taha, Mozhgan

  Monitoring & Detection:
    Mozhgan, Atosa, Maede

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"#;