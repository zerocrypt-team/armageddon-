use std::fmt;

#[derive(Debug)]
pub enum ArmageddonError {
    Io(std::io::Error),
    Anyhow(anyhow::Error),
    Config(String),
    PermissionDenied,
    Network(String),
}

impl fmt::Display for ArmageddonError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Io(e) => write!(f, "IO error: {}", e),
            Self::Anyhow(e) => write!(f, "Error: {}", e),
            Self::Config(s) => write!(f, "Config error: {}", s),
            Self::PermissionDenied => write!(f, "Root/Administrator privileges required"),
            Self::Network(s) => write!(f, "Network error: {}", s),
        }
    }
}

impl std::error::Error for ArmageddonError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Io(e) => Some(e),
            Self::Anyhow(e) => Some(e),
            _ => None,
        }
    }
}

impl From<std::io::Error> for ArmageddonError {
    fn from(e: std::io::Error) -> Self { Self::Io(e) }
}
impl From<anyhow::Error> for ArmageddonError {
    fn from(e: anyhow::Error) -> Self { Self::Anyhow(e) }
}