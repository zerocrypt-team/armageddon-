use anyhow::Result;
use pnet::packet::{
    ip::IpNextHeaderProtocols,
    ipv4::Ipv4Packet,
    Packet,
};
use pnet::util;
use std::net::Ipv4Addr;
use crate::injector::linux::LinuxRawSocket;

pub async fn send_tcp_via_ip(
    raw: &LinuxRawSocket,
    src: Ipv4Addr,
    dst: Ipv4Addr,
    tcp_packet: &[u8],
    ttl: u8,
    identification: u16,
    tos: u8,
    header_hide: bool,
) -> Result<()> {
    if header_hide && tcp_packet.len() > 20 {
        let (tcp_hdr, tcp_body) = tcp_packet.split_at(20);
        let ip1 = build_ip_fragment(src, dst, tcp_hdr, ttl, identification, 0, true, tos);
        raw.send_ip_packet(dst, &ip1).await?;

        let offset = (20 / 8) as u16;
        let ip2 = build_ip_fragment(src, dst, tcp_body, ttl, identification, offset, false, tos);
        raw.send_ip_packet(dst, &ip2).await?;
    } else {
        let ip_packet = build_ip_packet(src, dst, tcp_packet, ttl, identification, tos);
        raw.send_ip_packet(dst, &ip_packet).await?;
    }
    Ok(())
}

fn build_ip_packet(src: Ipv4Addr, dst: Ipv4Addr, payload: &[u8], ttl: u8, identification: u16, tos: u8) -> Vec<u8> {
    let total_len = 20 + payload.len();
    let mut buf = vec![0u8; total_len];
    let mut ip = Ipv4Packet::new(&mut buf).unwrap();
    ip.set_version(4);
    ip.set_header_length(5);
    ip.set_total_length(total_len as u16);
    ip.set_identification(identification);
    ip.set_flags(0);
    ip.set_fragment_offset(0);
    ip.set_ttl(ttl);
    ip.set_next_level_protocol(IpNextHeaderProtocols::Tcp);
    ip.set_source(src);
    ip.set_destination(dst);
    ip.set_dscp(tos >> 2);
    ip.set_ecn(tos & 0x03);
    ip.set_payload(payload);
    ip.set_checksum(util::checksum(ip.packet(), 1));
    buf
}

fn build_ip_fragment(src: Ipv4Addr, dst: Ipv4Addr, payload: &[u8], ttl: u8, identification: u16, offset_8byte: u16, more_fragments: bool, tos: u8) -> Vec<u8> {
    let total_len = 20 + payload.len();
    let mut buf = vec![0u8; total_len];
    let mut ip = Ipv4Packet::new(&mut buf).unwrap();
    ip.set_version(4);
    ip.set_header_length(5);
    ip.set_total_length(total_len as u16);
    ip.set_identification(identification);
    ip.set_flags(if more_fragments { 0x20 } else { 0 });
    ip.set_fragment_offset(offset_8byte);
    ip.set_ttl(ttl);
    ip.set_next_level_protocol(IpNextHeaderProtocols::Tcp);
    ip.set_source(src);
    ip.set_destination(dst);
    ip.set_dscp(tos >> 2);
    ip.set_ecn(tos & 0x03);
    ip.set_payload(payload);
    ip.set_checksum(util::checksum(ip.packet(), 1));
    buf
}