use anyhow::Result;
use etherparse::TlsClientHello;
use rand::Rng;

pub struct ClientHelloInfo {
    pub sni: String,
    pub raw: Vec<u8>,
    pub sni_start: usize,
    pub sni_len: usize,
}

pub fn parse_client_hello(payload: &[u8]) -> Option<ClientHelloInfo> {
    if let Ok((_, hello)) = TlsClientHello::from_slice(payload) {
        let sni = hello.server_name()?.to_string();
        let sni_bytes = sni.as_bytes();
        let sni_start = payload.windows(sni_bytes.len()).position(|w| w == sni_bytes)?;
        Some(ClientHelloInfo {
            sni,
            raw: payload.to_vec(),
            sni_start,
            sni_len: sni_bytes.len(),
        })
    } else {
        None
    }
}

// Placeholder: correct minimal TLS 1.2 ClientHello with 10-byte placeholder "zzzzzzzzzz"
const TLS_HELLO_TEMPLATE: &[u8] = &[
    0x16, 0x03, 0x01, 0x00, 0x5b, // TLS record
    0x01, 0x00, 0x00, 0x57,       // handshake
    0x03, 0x03,                   // version
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, // random
    0x00,                         // session id length
    0x00, 0x02,                   // cipher suites len
    0x00, 0x2f,                   // TLS_RSA_WITH_AES_128_CBC_SHA
    0x01, 0x00,                   // compression methods
    0x00, 0x12,                   // extensions length = 18
    0x00, 0x00, 0x00, 0x0e,       // SNI extension type 0, length 14
    0x00, 0x0c,                    // server name list length = 12
    0x00, 0x08,                    // hostname type
    0x00, 0x0a,                    // hostname length 10
    // placeholder 10 bytes:
    b'z', b'z', b'z', b'z', b'z', b'z', b'z', b'z', b'z', b'z'
];

pub fn build_fake_client_hello(sni: &str, _rng: &mut impl Rng) -> Result<Vec<u8>> {
    let mut hello = TLS_HELLO_TEMPLATE.to_vec();
    let placeholder = b"zzzzzzzzzz";
    if let Some(pos) = hello.windows(10).position(|w| w == placeholder) {
        let sni_bytes = sni.as_bytes();
        let len = sni_bytes.len().min(10);
        hello[pos..pos+len].copy_from_slice(&sni_bytes[..len]);
        // pad with zeros for remaining
        for i in len..10 {
            hello[pos+i] = 0;
        }
    }
    Ok(hello)
}