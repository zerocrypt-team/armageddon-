use rand::Rng;

const GREASE_TYPES: [u16; 16] = [
    0x0A0A, 0x1A1A, 0x2A2A, 0x3A3A, 0x4A4A, 0x5A5A, 0x6A6A, 0x7A7A,
    0x8A8A, 0x9A9A, 0xAAAA, 0xBABA, 0xCACA, 0xDADA, 0xEAEA, 0xFAFA,
];

pub fn generate_grease_extension(rng: &mut impl Rng, size_min: usize, size_max: usize) -> Vec<u8> {
    let size = rng.gen_range(size_min..=size_max);
    let grease_type = GREASE_TYPES[rng.gen_range(0..GREASE_TYPES.len())];
    let mut ext = Vec::with_capacity(4 + size);
    ext.extend_from_slice(&grease_type.to_be_bytes());
    ext.extend_from_slice(&(size as u16).to_be_bytes());
    ext.resize(4 + size, 0);
    for i in 4..ext.len() {
        ext[i] = rng.gen();
    }
    ext
}