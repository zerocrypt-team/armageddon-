use anyhow::Result;
use pnet::packet::{tcp::TcpPacket, Packet};
use std::net::Ipv4Addr;

pub struct TcpOptions {
    pub seq: u32,
    pub ack: u32,
    pub sport: u16,
    pub dport: u16,
    pub window: u16,
    pub flags: u8,
    pub urg: bool,
    pub urg_ptr: u16,
    pub timestamp: Option<u32>,
}

pub fn build_tcp_packet(
    src_ip: Ipv4Addr,
    dst_ip: Ipv4Addr,
    options: &TcpOptions,
    payload: &[u8],
) -> Result<Vec<u8>> {
    let hdr_len = if options.timestamp.is_some() { 32 } else { 20 };
    let total_len = hdr_len + payload.len();
    let mut buf = vec![0u8; total_len];

    {
        let mut tcp = TcpPacket::new(&mut buf[..total_len]).ok_or_else(|| anyhow::anyhow!("TCP buffer size"))?;
        tcp.set_source(options.sport);
        tcp.set_destination(options.dport);
        tcp.set_sequence(options.seq);
        tcp.set_acknowledgement(options.ack);
        tcp.set_data_offset((hdr_len / 4) as u8);
        tcp.set_flags(options.flags);
        tcp.set_window(options.window);
        tcp.set_urgent_ptr(if options.urg { options.urg_ptr } else { 0 });

        if let Some(ts) = options.timestamp {
            buf[20] = 8;
            buf[21] = 10;
            buf[22..26].copy_from_slice(&ts.to_be_bytes());
            buf[26..30].copy_from_slice(&0u32.to_be_bytes());
        }

        tcp.set_payload(payload);
        let csum = tcp_checksum(&buf[..total_len], src_ip, dst_ip);
        tcp.set_checksum(csum);
    }

    Ok(buf)
}

fn tcp_checksum(segment: &[u8], src: Ipv4Addr, dst: Ipv4Addr) -> u16 {
    let mut sum = 0u32;

    let octets = src.octets();
    sum += u16::from_be_bytes([octets[0], octets[1]]) as u32;
    sum += u16::from_be_bytes([octets[2], octets[3]]) as u32;
    let octets = dst.octets();
    sum += u16::from_be_bytes([octets[0], octets[1]]) as u32;
    sum += u16::from_be_bytes([octets[2], octets[3]]) as u32;
    sum += 6u32; // TCP protocol
    let tcp_len = segment.len() as u32;
    sum += tcp_len;

    let mut i = 0;
    while i < segment.len() {
        let word = if i + 1 < segment.len() {
            u16::from_be_bytes([segment[i], segment[i+1]]) as u32
        } else {
            (segment[i] as u32) << 8
        };
        sum += word;
        i += 2;
    }
    while sum >> 16 != 0 {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    !(sum as u16)
}