use anyhow::Result;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use crate::transport::{Transport, AsyncReadWrite};

pub struct Socks5Server {
    addr: SocketAddr,
    transport: Arc<dyn Transport>,
}

impl Socks5Server {
    pub fn new(addr: SocketAddr, transport: Arc<dyn Transport>) -> Self {
        Self { addr, transport }
    }

    pub async fn run(&self) -> Result<()> {
        let listener = TcpListener::bind(&self.addr).await?;
        log::info!("SOCKS5 server listening on {}", self.addr);

        loop {
            let (stream, peer_addr) = listener.accept().await?;
            log::debug!("Accepted connection from {}", peer_addr);
            let transport = self.transport.clone();
            tokio::spawn(async move {
                if let Err(e) = handle_socks5(stream, transport).await {
                    log::error!("SOCKS5 error for {}: {}", peer_addr, e);
                }
            });
        }
    }
}

async fn handle_socks5(mut client: TcpStream, transport: Arc<dyn Transport>) -> Result<()> {
    // 1. Handshake (no auth)
    let mut buf = [0u8; 257];
    client.read_exact(&mut buf[..2]).await?;
    let nmethods = buf[1] as usize;
    client.read_exact(&mut buf[..nmethods]).await?;
    client.write_all(&[0x05, 0x00]).await?;

    // 2. Request
    client.read_exact(&mut buf[..4]).await?;
    let cmd = buf[1];
    let atyp = buf[3];
    let dst_addr = match atyp {
        0x01 => { // IPv4
            client.read_exact(&mut buf[..4]).await?;
            format!("{}.{}.{}.{}", buf[0], buf[1], buf[2], buf[3])
        }
        0x03 => { // Domain name
            client.read_exact(&mut buf[..1]).await?;
            let len = buf[0] as usize;
            client.read_exact(&mut buf[..len]).await?;
            String::from_utf8_lossy(&buf[..len]).to_string()
        }
        _ => anyhow::bail!("Unsupported address type"),
    };
    client.read_exact(&mut buf[..2]).await?;
    let dst_port = u16::from_be_bytes([buf[0], buf[1]]);

    if cmd != 0x01 {
        send_reply(&mut client, 0x07).await?; // Command not supported
        anyhow::bail!("Unsupported SOCKS5 command");
    }

    log::info!("SOCKS5 connect to {}:{}", dst_addr, dst_port);
    let mut remote: Box<dyn AsyncReadWrite> = transport.connect(&dst_addr, dst_port).await?;

    // Reply success
    send_reply(&mut client, 0x00).await?;

    // 3. Relay data between client and remote tunnel
    let (mut client_reader, mut client_writer) = client.into_split();
    let upload = tokio::io::copy(&mut client_reader, &mut remote);
    // Cannot copy from remote to client_writer because remote is Box<dyn AsyncReadWrite> and we need to split it.
    // We'll use tokio::io::copy_bidirectional or manually pipe.
    let (mut remote_reader, mut remote_writer) = tokio::io::split(remote);
    let download = tokio::io::copy(&mut remote_reader, &mut client_writer);
    // Upload: client -> remote
    let upload_task = tokio::spawn(async move {
        tokio::io::copy(&mut client_reader, &mut remote_writer).await
    });
    let download_task = tokio::spawn(async move {
        download.await
    });

    let _ = tokio::try_join!(upload_task, download_task);
    Ok(())
}

async fn send_reply(client: &mut TcpStream, rep: u8) -> Result<()> {
    let reply = [0x05, rep, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
    client.write_all(&reply).await?;
    Ok(())
}