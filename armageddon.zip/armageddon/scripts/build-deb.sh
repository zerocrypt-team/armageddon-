#!/bin/bash
set -e

VERSION="1.0.0"
TARGET="armageddon_${VERSION}_amd64"
BIN="target/release/armageddon"
DEB_ROOT="$TARGET/usr/local/bin"
CONTROL_DIR="$TARGET/DEBIAN"

mkdir -p "$DEB_ROOT" "$CONTROL_DIR"
cp "$BIN" "$DEB_ROOT/armageddon"

cat > "$CONTROL_DIR/control" <<EOF
Package: armageddon
Version: $VERSION
Section: net
Priority: optional
Architecture: amd64
Maintainer: Team ZeroCrypt <zerocrypt@example.com>
Description: Ultimate DPI Evasion Framework
 Armageddon is a modular, multi-layered tool for bypassing DPI systems.
 It runs client-side and requires root privileges.
EOF

dpkg-deb --build "$TARGET"
echo "Package built: ${TARGET}.deb"