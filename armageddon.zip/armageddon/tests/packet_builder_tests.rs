use armageddon::packet_builder::{tcp, ip, tls};
use std::net::Ipv4Addr;
use rand::SeedableRng;
use rand::rngs::StdRng;

#[test]
fn test_tcp_checksum_valid() {
    let src: Ipv4Addr = "10.0.0.1".parse().unwrap();
    let dst: Ipv4Addr = "10.0.0.2".parse().unwrap();
    let payload = b"HELLO";
    let pkt = tcp::build_tcp_packet(
        src, dst,
        &tcp::TcpOptions {
            seq: 1000, ack: 2000,
            sport: 12345, dport: 443,
            window: 65535,
            flags: 0x18,
            urg: false, urg_ptr: 0,
            timestamp: None,
        },
        payload,
    )
    .expect("TCP packet build");
    // Re-parse and verify checksum
    use pnet::packet::tcp::TcpPacket;
    let tcp = TcpPacket::new(&pkt).unwrap();
    assert!(tcp.get_checksum() != 0, "Checksum should be non-zero");
}

#[test]
fn test_fake_client_hello_has_sni() {
    let mut rng = StdRng::seed_from_u64(42);
    let hello = tls::build_fake_client_hello("test.com", &mut rng).unwrap();
    let hello_str = String::from_utf8_lossy(&hello);
    assert!(hello_str.contains("test.com"), "SNI not found in ClientHello");
}